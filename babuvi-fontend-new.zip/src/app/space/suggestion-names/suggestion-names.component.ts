import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suggestion-names',
  templateUrl: './suggestion-names.component.html',
  styleUrls: ['./suggestion-names.component.scss']
})
export class SuggestionNamesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
