import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-space-tab-name',
  templateUrl: './space-tab-name.component.html',
  styleUrls: ['./space-tab-name.component.scss']
})
export class SpaceTabNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
