import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'ms-space',
  templateUrl: './space.component.html',
  styleUrls: ['./space.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class SpaceComponent implements OnInit {
  constructor() {

  }

  ngOnInit() {
  }
}

