export const GLOBAL_CONSTANT = {
  ORDERS_SERVICES: [] = [
    {id: '0', value: '選択なし'},
  ]
};
