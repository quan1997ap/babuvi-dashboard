import { Routes } from '@angular/router';

import { listUserManagerComponent } from './list-user/list-user-manager.component';

export const AdminManagerRoutes: Routes = [{
  path: '',
  component: listUserManagerComponent
}];
