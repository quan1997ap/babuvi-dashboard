import { Component, OnInit,ViewEncapsulation } from '@angular/core';


@Component({
    selector: 'ms-modern-card',
    templateUrl:'./modern-card-component.html',
    styleUrls: ['./modern-card-component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ModernCardComponent implements OnInit {

  constructor() {}

  ngOnInit() {

  }
	
}



