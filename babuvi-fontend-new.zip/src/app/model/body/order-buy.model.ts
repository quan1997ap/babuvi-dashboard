import {OrderDetailRO} from '../ro/order-detail.model';

export class OrderBuy extends OrderDetailRO {
}
