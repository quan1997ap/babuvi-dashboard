export class RsLogin{
    username: string = null;
    password: string = null;
    clientAppCode: string = null;
}