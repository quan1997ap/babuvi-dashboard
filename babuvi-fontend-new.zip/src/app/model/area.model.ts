export class AreaModel {
    areaId;
    areaCode;
    areaType;
    areaName;
    shortDisplay;
    parentAreaId;
    allParent;
    status;
}
