class BasicModel {
    
}