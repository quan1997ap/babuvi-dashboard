export class NewAddress {
    success: boolean = true;
    code: string = "";
    message: string = "";
    data: string = "";
}