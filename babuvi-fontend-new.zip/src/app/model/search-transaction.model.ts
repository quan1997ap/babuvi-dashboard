export class searchTransactionModel {
    WalletId: number = null;
    WalletTransactionCode: string = null;
    StartDate: Date = null;
    EndDate: Date = null;
    WalletTransactionType: string = null;
    Status: string = null;
    Content: string = null;
}