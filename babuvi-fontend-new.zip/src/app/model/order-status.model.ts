export class OrderStatus {
    apDomainId: number = 0;
    type = null;
    code: string = '1';
    value: string = '1';
    displayValue: string = 'Tạo mới';
    shortDisplay = null;
    status = null;
    ord: number = 1;
}
