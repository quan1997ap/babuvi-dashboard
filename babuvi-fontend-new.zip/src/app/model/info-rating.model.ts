export class InfoRating {
    exchangeRate: string = null;
    cashBalance: string = null;
    symbolsLocation: string = null;
    symbolsDisplay: string = null;
    cartItemCount: number = null;
    notificationSystemCount: number = null;
    notificationCount: number = null;
}