export class ChatDTO {
    orderId: number = 0;
    userId: number = 0;
    content: string = "";
}

