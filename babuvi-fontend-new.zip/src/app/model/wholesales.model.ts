export class WholeSales{
    begin: number = 0;
    end: number = 0;
    price: string= "";
}