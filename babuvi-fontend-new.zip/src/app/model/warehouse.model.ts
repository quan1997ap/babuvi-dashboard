export class Warehouse {
    warehouseId;
    warehouseCode;
    name;
    customerName;
    consignmentName;
    address;
    phone;
    location;
    status;
}
