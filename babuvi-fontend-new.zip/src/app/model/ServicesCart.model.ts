export class ServiceCart {
    serviceCartId: number = 0;
    serviceId: number = 0;
    cartId: number = 0;
    amount: number = 0;
    feeType: number = 0;
}