export class WarehouseExpDetail {
    warehouseExpDetailId;
    warehouseExpId;
    merchandiseWarehouseId;
    merchandiseCode;
    status;
    netWeight;
    chargedWeight;
    paymentWeight;
    length;
    width;
    height;
    shelfPosition;
}
