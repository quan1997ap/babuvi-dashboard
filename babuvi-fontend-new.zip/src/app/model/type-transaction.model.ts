export class TypeTransactionModel {
    apDomainId: number = null;
    code: string = null;
    displayValue: string = null;
    ord: string = null;
    shortDisplay: string = null;
    status: string = null;
    type: string = null;
    value: string = null;
}
