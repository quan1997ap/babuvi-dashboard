export class ApDomain {
    apDomainId;
    type;
    code;
    value;
    displayValue;
    shortDisplay;
    status;
    ord;
}
