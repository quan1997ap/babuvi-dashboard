export class WarehouseImpDetail {
    warehouseImpDetailId;
    warehouseImpId;
    merchandiseId;
    merchandiseCode;
    netWeight;
    chargedWeight;
    paymentWeight;
    length;
    width;
    height;
    shelfPosition;
    lsImage;
    lsDataImage;
}
