export class CallFeeServicesInCart {
    serviceCartId: number = 0;
    serviceId: number = 0;
    cartId: number = 0;
    amount: string = "";
    feeType: number = 0;
}