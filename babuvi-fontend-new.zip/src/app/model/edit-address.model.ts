export class EditAddressModel {
    constructor(public title: string, public message: string, public data: any) {}
}