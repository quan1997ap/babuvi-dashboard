import {ApDomain} from './imp-exp-status.model';

export class DeliveryRequestType extends ApDomain {}
