export class LstServiceCart {
    serviceCartId: number = 0;
    serviceId: number = 0;
    serviceName: string = "";
    display: string = "";
    shortDisplay: string = "";
    description: string = "";
    cartId: number = 0;
    amount: number = 0;
    feeType: number = 0;
    isOption: number = 0;
    locationDisplay: number = 0;
    ord: number = 0;
    isChecked ?: boolean = false;
}