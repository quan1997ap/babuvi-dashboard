export class MenuFromServer{
    controlId: number;
    controlCode: string;
    parentId: number;
    name: string;
    status: string;
    ord: number;
    pathFile: string;
    type: string;
    icon: string;
}