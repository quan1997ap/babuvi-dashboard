export class Topup {
    WalletId: number;
    Amount: number;
    PaymentId: string;
    PaymentType: string;
    Content: string;
    Status: string;
    CreatedUser:number;
}
