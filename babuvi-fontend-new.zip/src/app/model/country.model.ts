export class lstCountry {
    areaId: number = 0;
    areaCode: string = "";
    areaType: number = 0;
    areaName: string = "";
    shortDisplay: string = "";
    parentAreaId: number = 0;
    allParent: string = "";
    status: string = "";
}