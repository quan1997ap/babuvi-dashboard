export class RequestModel {
    lsId: number[];
    loginData: LoginData = new LoginData();
}

export class LoginData {
    username;
    password;

}
