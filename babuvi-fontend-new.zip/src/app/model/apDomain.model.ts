export class ApDomain {
    apDomainId: number;
    type: string;
    code: string;
    value: string;
    displayValue: string;
    shortDisplay: string;
    status: string;
    ord: number;
}
