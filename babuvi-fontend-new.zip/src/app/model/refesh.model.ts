export class RefeshTokenModel {
    accesstoken: string = '';
    refreshtokencode: string = '';
    ClientAppCode: string = '';
}