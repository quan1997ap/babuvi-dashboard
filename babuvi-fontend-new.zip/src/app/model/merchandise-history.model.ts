export class MerchandiseHistory {
    merchandiseHistoryId: number;
    merchandiseId: number;
    merchandiseStatus: string;
    merchandiseStatusDisplay: string;
    historyDate: Date;
    attachFileUrl: [];
    content: string;
    createdUserId: number;
}
