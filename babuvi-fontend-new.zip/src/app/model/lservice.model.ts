export class LService {
    serviceOrderId: number = null;
    serviceId: number = null;
    orderId: string = null;
    amount: number = null;
    amountCny: number = null;
    amountCnyBuy: number = null;
    feeType: string = null;
    feeTypeDisplay: string = null;
    display: string = null;
    shortDisplay: string = null;
    ord: string = null;
}
