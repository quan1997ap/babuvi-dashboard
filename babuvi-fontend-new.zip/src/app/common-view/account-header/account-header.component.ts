import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'account-header',
    templateUrl:'./account-header.component.html',
    styleUrls: ['./account-header.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AccountHeaderComponent implements OnInit {

  constructor() {}

  ngOnInit() {

  }

}



