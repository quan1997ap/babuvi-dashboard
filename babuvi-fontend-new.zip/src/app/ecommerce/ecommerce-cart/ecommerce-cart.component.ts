import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  'selector': 'ms-ecommerce-cart',
  templateUrl:'./ecommerce-cart-component.html',
  styleUrls: ['./ecommerce-cart-component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EcommerceCartComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}