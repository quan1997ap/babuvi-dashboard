import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  'selector': 'ms-ecommerce-product-detail',
  templateUrl:'./ecommerce-product-detail-component.html',
  styleUrls: ['./ecommerce-product-detail-component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EcommerceProductDetailComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}