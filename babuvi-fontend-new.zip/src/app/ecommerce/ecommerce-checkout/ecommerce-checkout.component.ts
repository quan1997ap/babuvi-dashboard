import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  'selector': 'ms-ecommerce-checkout',
  templateUrl:'./ecommerce-checkout-component.html',
  styleUrls: ['./ecommerce-checkout-component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EcommerceCheckoutComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}