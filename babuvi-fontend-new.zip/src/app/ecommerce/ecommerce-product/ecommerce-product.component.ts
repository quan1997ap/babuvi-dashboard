import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  'selector': 'ms-ecommerce-product',
  templateUrl:'./ecommerce-product-component.html',
  styleUrls: ['./ecommerce-product-component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EcommerceProductComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}