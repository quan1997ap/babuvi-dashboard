import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'ms-timeline',
    templateUrl:'./timeline-component.html',
    styleUrls: ['./timeline-component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TimelineComponent implements OnInit {

  constructor() {}

  ngOnInit() {

  }

}



