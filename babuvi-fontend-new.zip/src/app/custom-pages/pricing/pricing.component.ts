import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'ms-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.scss'],
  encapsulation: ViewEncapsulation.None
  
})
export class PricingComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
