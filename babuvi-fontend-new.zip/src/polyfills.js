"use strict";

Object.defineProperty(exports, "__esModule", {
    value: !0
}), require("core-js/es6/symbol"), require("core-js/es6/object"), require("core-js/es6/function"), 
require("core-js/es6/parse-int"), require("core-js/es6/parse-float"), require("core-js/es6/number"), 
require("core-js/es6/math"), require("core-js/es6/string"), require("core-js/es6/date"), 
require("core-js/es6/array"), require("core-js/es6/regexp"), require("core-js/es6/map"), 
require("core-js/es6/set"), require("core-js/es6/reflect"), require("core-js/es7/reflect"), 
require("zone.js/dist/zone"), require("intl"), require("intl/locale-data/jsonp/en.js");

// Add global to window, assigning the value of window itself.
(window as any).global = window;